# MIT License

# Copyright (c) 2023-present Poing Studios

# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:

# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.

# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

class_name MobileSingletonPlugin

static func _get_plugin(plugin_name: String, is_required := true) -> Object:
	if (Engine.has_singleton(plugin_name)):
		return Engine.get_singleton(plugin_name)

	var os_name := OS.get_name()
	if os_name != "Android" and os_name != "iOS":
		return null

	var location := "'res://addons/admob/android/config.gd' and 'Use Gradle Build' is enabled" if os_name == "Android" else "the 'Plugins' section of the Export tab"
	var message := plugin_name + " not found, make sure it is enabled in " + location

	if is_required:
		printerr(message)
	else:
		push_warning(message)

	return null

static func safe_connect(plugin: Object, signal_name: String, callable: Callable, flags := 0) -> void:
	if plugin and not plugin.is_connected(signal_name, callable):
		plugin.connect(signal_name, callable, flags)
